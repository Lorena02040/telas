import 'package:flutter/material.dart';

class TicketShapeBorder extends ShapeBorder {
  final double radius;
  
  const TicketShapeBorder({this.radius = 10.0});

  @override
  EdgeInsetsGeometry get dimensions => const EdgeInsets.all(0);

  @override
  Path getInnerPath(Rect rect, {TextDirection? textDirection}) {
    return Path()
      ..addRRect(RRect.fromRectAndRadius(rect, Radius.circular(radius)));
  }

  @override
  Path getOuterPath(Rect rect, {TextDirection? textDirection}) {
    final path = Path();
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));
    path.addRRect(rrect);

    // Círculos para o efeito "perfurado" na lateral direita
    final dashHeight = 10.0;
    final holeRadius = 5.0;
    
    path.addOval(Rect.fromCircle(center: Offset(rect.width, rect.height / 2 - dashHeight), radius: holeRadius));
    path.addOval(Rect.fromCircle(center: Offset(rect.width, rect.height / 2 + dashHeight), radius: holeRadius));

    return path;
  }
  
  @override
  void paint(Canvas canvas, Rect rect, {TextDirection? textDirection}) {}

  @override
  ShapeBorder scale(double t) {
    return TicketShapeBorder(radius: radius * t);
  }
}