import 'package:flutter/material.dart';
import 'dart:math';

class TicketPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF4C66A2)
      ..style = PaintingStyle.fill;
    
    final path = Path()
      ..addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.width, size.height), Radius.circular(15.0)));
    
    // Desenha o formato do bilhete
    canvas.drawPath(path, paint);

    // Desenha a seção lateral roxa
    final purplePaint = Paint()..color = Color(0xFF6E569D);
    final purplePath = Path()
      ..addRRect(RRect.fromRectAndRadius(
          Rect.fromLTWH(size.width - 40, 0, 40, size.height), Radius.circular(15.0)));
    canvas.drawPath(purplePath, purplePaint);

    // Desenha a linha pontilhada
    final dashPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    const double dashWidth = 5;
    const double dashSpace = 3;
    double startY = 10;
    while (startY < size.height - 10) {
      canvas.drawLine(
        Offset(size.width - 40, startY),
        Offset(size.width - 40, startY + dashWidth),
        dashPaint,
      );
      startY += dashWidth + dashSpace;
    }

    // Desenha os círculos nas bordas
    final circlePaint = Paint()..color = Color(0xFFF0F0F0);
    canvas.drawCircle(Offset(size.width - 40, 0), 10, circlePaint);
    canvas.drawCircle(Offset(size.width - 40, size.height), 10, circlePaint);

    // Desenha o texto rotacionado
    TextPainter textPainter = TextPainter(
      text: TextSpan(
        text: 'EMBARQUE E DESEMBARQUE',
        style: TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();

    canvas.save();
    canvas.translate(size.width - 20, size.height / 2);
    canvas.rotate(-pi / 2);
    textPainter.paint(canvas, Offset(-textPainter.width / 2, -textPainter.height / 2));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}