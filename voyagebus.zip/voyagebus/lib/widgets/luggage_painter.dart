import 'package:flutter/material.dart';

class LuggagePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Fundo azul escuro
    final paint = Paint()..color = Color(0xFF4C66A2);
    final path = Path()
      ..addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.width, size.height), Radius.circular(15.0)));
    canvas.drawPath(path, paint);

    // Forma superior roxa
    final purplePaint = Paint()..color = Color(0xFF6E569D);
    final purplePath = Path()
      ..addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.width, size.height * 0.15), Radius.circular(15.0)));
    canvas.drawPath(purplePath, purplePaint);
    
    // Círculos inferiores
    final circlePaint = Paint()..color = Color(0xFFF0F0F0);
    canvas.drawCircle(Offset(size.width * 0.25, size.height - 10), 5, circlePaint);
    canvas.drawCircle(Offset(size.width * 0.75, size.height - 10), 5, circlePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}