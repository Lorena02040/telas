import 'package:flutter/material.dart';

class BusQrPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black;
    final path = Path()
      ..moveTo(size.width * 0.1, size.height * 0.6)
      ..lineTo(size.width * 0.9, size.height * 0.6)
      ..lineTo(size.width * 0.9, size.height * 0.8)
      ..lineTo(size.width * 0.1, size.height * 0.8)
      ..close();
    
    canvas.drawPath(path, paint);

    // Rodas
    canvas.drawCircle(Offset(size.width * 0.25, size.height * 0.8), size.width * 0.05, paint);
    canvas.drawCircle(Offset(size.width * 0.75, size.height * 0.8), size.width * 0.05, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}